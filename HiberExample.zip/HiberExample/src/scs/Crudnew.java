package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import dal.Datahelper;

public class Crudnew {
	
	
	static void selectRecord()
	{
		Datahelper.connection();
		Query q = Datahelper.dql("from Stu s");
		List lst = q.list();
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			Stu s =(Stu)it.next();
			System.out.println(s.getRno() + " "+s.getSname());
		}
		Datahelper.closeconn();
		
	}
	static void insertRecord(int rno,String sname)
	{
		
		Datahelper.connection();
		Stu s = new Stu();
		s.setRno(rno);
		s.setSname(sname);
		Datahelper.dmlInsert(s);
		Datahelper.closeconn();
		
	}
	static void deleteRecord(int rno)
	{
		Datahelper.connection();
		Stu s = (Stu)Datahelper.dqlFind(Stu.class,rno);
		
		Datahelper.dmlDelete(s);
		Datahelper.closeconn();
	}
	static void updaterecord(int rno,String sname)
	{
		Datahelper.connection();
		Stu s = (Stu)Datahelper.dqlFind(Stu.class,rno);
		Datahelper.dmlUpdate(s);
		Datahelper.closeconn();
	}
	
	public static void main(String[] args) {
	
		insertRecord(106,"Kshitij");
		//updaterecord(102, "abc");
		//deleteRecord(102);
	    selectRecord();
	    
	    
		

	}

}
